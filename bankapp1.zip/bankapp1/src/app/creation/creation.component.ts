import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CreateService } from './create.service';
import { Account } from '../models/account';

@Component({
  selector: 'app-creation',
  templateUrl: './creation.component.html',
  styleUrls: ['./creation.component.css']
})
export class CreationComponent implements OnInit {

  private account:Account;
  private amount:number;
  private type:string;
  private pin:number;
  private flag:Boolean=false;
  constructor(private route: ActivatedRoute,private createServices:CreateService,private router: Router) {
  }

    

  ngOnInit() {
    this.account=null;
    this.amount=null;
    this.pin=null;
    this.type=null;
  }

  createEntry(){
    this.account=new Account();
    this.account.currentBalance=this.amount
    this.account.pin=this.pin;
    this.account.accountType=this.type;
    
      this.createServices.createEntry(this.account).subscribe((response)=>{
        this.router.navigate(['/account',response]);
        },
        (error) => {
        console.error('error caught in component');
        alert(error);
        console.log(error);
      })
    
  }

}

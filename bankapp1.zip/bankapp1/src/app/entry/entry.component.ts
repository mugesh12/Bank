import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EntryService } from './entry.service';
import { Account } from '../models/account';
import { Entry } from '../models/Entry';

@Component({
  selector: 'app-entry',
  templateUrl: './entry.component.html',
  styleUrls: ['./entry.component.css']
})
export class EntryComponent implements OnInit {

  private accountNo:number;
  private account:Account;
  private entry:Entry;
  private amount:number;
  private type:string;
  private pin:number;
  private flag:Boolean=false;
  constructor(private route: ActivatedRoute,private entryServices:EntryService,private router: Router) {
    this.route.params.subscribe( params =>{ console.log(params);
      this.accountNo=params.id} );
}

  ngOnInit() {
    this.entry=null;
    this.pin=null;
    
    this.amount=null;
    this.type=null;
    this.getAccounts();
  }

  getAccounts(){
    this.entryServices.getAllAccount(this.accountNo).subscribe((response)=>{
      this.account=response;
      if(this.account.accountEntry.length){
        this.flag=true;
      }},
      (error) => {
      console.error('error caught in component');
      alert(error);
      console.log(error);
      this.router.navigate(['/root']);
    })
  }
  activate(){
    this.entryServices.activateAccount(this.accountNo).subscribe((response)=>{
      this.ngOnInit();
      },
      (error) => {
      console.error('error caught in component');
      alert(error);
      console.log(error);
    })
  }

  deActivate(){
    this.entryServices.blockAccount(this.accountNo).subscribe((response)=>{
      this.ngOnInit();
      },
      (error) => {
      console.error('error caught in component');
      alert(error);
      console.log(error);
    })
  }
  createEntry(){
    this.entry=new Entry();
    this.entry.accountId=this.accountNo
    this.entry.amount=this.amount;
    this.entry.entryType=this.type;
    if(this.type=="Debit"){
    if(this.pin===this.account.pin){
      this.entryServices.createEntry(this.accountNo,this.entry).subscribe((response)=>{this.ngOnInit();
        },
        (error) => {
        console.error('error caught in component');
        alert(error);
        console.log(error);
      })
    }else{
      alert("Invalid pin");
    }
    }else{
      this.entryServices.createEntry(this.accountNo,this.entry).subscribe((response)=>{this.ngOnInit();
      },
      (error) => {
      console.error('error caught in component');
      alert(error);
      console.log(error);
    })
  }
  }

}

import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Account } from '../models/account';

@Injectable({
  providedIn: 'root'
})
export class EntryService {

  constructor(private http:HttpClient){}
  private handleError(err: HttpErrorResponse) {
    console.log(err)
    let errMsg: string = '';
    if (err.error instanceof Error) {
        errMsg = err.error.message;
        console.log(errMsg)
    }
    else if (typeof err.error === 'string') {
        errMsg = JSON.parse(err.error).message
    }
    else {
        if (err.status == 0) {
            errMsg = "A connection to back end can not be established.";
        } else {
            errMsg = err.error.message;
        }
    }
    return throwError(errMsg);
}
getAllAccount(id): Observable<Account> {
    let url: string = "http://localhost:7070/bank/account/"+id;
    return this.http.get<Account>(url)
        .pipe(catchError(this.handleError));
}

blockAccount(id): Observable<Boolean> {
  let url: string = "http://localhost:7070/bank/block/"+id;
  return this.http.post<Boolean>(url,null)
      .pipe(catchError(this.handleError));
}
activateAccount(id): Observable<Boolean> {
  let url: string = "http://localhost:7070/bank/activate/"+id;
  return this.http.post<Boolean>(url,null)
      .pipe(catchError(this.handleError));
}

createEntry(id,entr): Observable<Boolean> {
  let url: string = "http://localhost:7070/bank/addEntry/"+id;
  return this.http.post<Boolean>(url,entr)
      .pipe(catchError(this.handleError));
}
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from './account.service';
import { Account } from '../models/account';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  title='Acconts';
  private accounts:Account[];
  constructor(private accountServices:AccountService,private router: Router) { }

  ngOnInit() {
    this.getAllAccounts();
  }
  getAllAccounts(){
    this.accountServices.getAllAccount().subscribe((response)=>{
      this.accounts=response;
      console.log(this.accounts);},
      (error) => {
      console.error('error caught in component');
      alert(error);
      console.log(error);
      this.router.navigate(['/root']);
    })
  }

  gotoDetail(accoun): void {
    console.log(accoun);
    this.router.navigate(['/account', accoun]);
  }
  

}

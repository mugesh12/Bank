import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root1',
  templateUrl: './root1.component.html',
  styleUrls: ['./root1.component.css']
})
export class Root1Component implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  getAccounts(){
    
      this.router.navigate(['/allAccount']);
  }
  create(){
    
    this.router.navigate(['/create']);
}

}

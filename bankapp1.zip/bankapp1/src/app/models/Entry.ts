export class Entry{
    entryId:number;
	accountId:number;
	entryTimeStamp:Date;
	entryType:string;
	amount:number;
    amountAfterTransaction:number;
}
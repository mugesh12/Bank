import { Entry } from "./Entry";

export class Account{
    accountId:number;
	accountType:String;
	creditBalance:number;
	currentBalance:number;
	debitBalance:number;
	activeFlag:Boolean;
	createdDate:Date;
	pin:number;
	accountEntry:Entry[];
}
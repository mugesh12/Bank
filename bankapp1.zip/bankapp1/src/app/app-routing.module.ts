import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountComponent } from './account/account.component';
import { Root1Component } from './root1/root1.component';
import { EntryComponent } from './entry/entry.component';
import { CreationComponent } from './creation/creation.component';


const routes: Routes = [ 
{path:'root',component:Root1Component},
{ path: '', redirectTo: '/root', pathMatch: 'full' },
{ path: 'account/:id', component: EntryComponent },
  { path: 'allAccount', component: AccountComponent },
  { path: 'create', component: CreationComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

package com.example.app2.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Table(name="AccountEntry")
@Entity
public class AccountEntryEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long entryId;
	private Long accountId;
	private Date entryTimeStamp;
	private String entryType;
	private BigDecimal amount;
	private BigDecimal amountAfterTransaction;
	@ManyToOne
	@JoinColumn(name="accountId",insertable=false,updatable=false)
	private CustomerAccountEntity customerAccountEntity;
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public Date getEntryTimeStamp() {
		return entryTimeStamp;
	}
	public void setEntryTimeStamp(Date entryTimeStamp) {
		this.entryTimeStamp = entryTimeStamp;
	}
	public String getEntryType() {
		return entryType;
	}
	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public Long getEntryId() {
		return entryId;
	}
	public void setEntryId(Long entryId) {
		this.entryId = entryId;
	}
	public BigDecimal getAmountAfterTransaction() {
		return amountAfterTransaction;
	}
	public void setAmountAfterTransaction(BigDecimal amountAfterTransaction) {
		this.amountAfterTransaction = amountAfterTransaction;
	}
	public CustomerAccountEntity getCustomerAccountEntity() {
		return customerAccountEntity;
	}
	public void setCustomerAccountEntity(CustomerAccountEntity customerAccountEntity) {
		this.customerAccountEntity = customerAccountEntity;
	} 
	
}

package com.example.app2.Service;

import java.util.List;

import com.example.app2.BankingException;
import com.example.app2.dto.AccountEntry;
import com.example.app2.dto.CustomerAccount;

public interface AccountService {
	public Long createAccount(CustomerAccount account) throws BankingException;
	public CustomerAccount getAccount(Long accountNo) throws BankingException;
	public Boolean addAccountEntry(Long accountNo,AccountEntry entry) throws BankingException;
	public List<CustomerAccount> getAllAccount() throws  BankingException;
	public Boolean blockAccount(Long accountNo) throws BankingException;
	public Boolean activateAccount(Long accountNo) throws BankingException;
}

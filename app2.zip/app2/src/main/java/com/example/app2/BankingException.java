package com.example.app2;

public class BankingException extends Exception{
	
	public BankingException(String message) {
		super(message);
	}

}

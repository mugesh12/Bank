package com.example.app2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.app2.entity.CustomerAccountEntity;

@Repository
public interface CustomerAccountRepository extends JpaRepository<CustomerAccountEntity,Long>{
	
	public CustomerAccountEntity findByAccountId(Long accountId);
	

}

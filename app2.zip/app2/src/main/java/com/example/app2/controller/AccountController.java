package com.example.app2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.app2.Service.AccountService;
import com.example.app2.BankingException;
import com.example.app2.dto.AccountEntry;
import com.example.app2.dto.CustomerAccount;

@RestController
@RequestMapping("/bank")
@CrossOrigin
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	@PostMapping(value = "/createAccount")
	public ResponseEntity<Long> createAccount(@RequestBody CustomerAccount account) throws BankingException {
		try{
			return new ResponseEntity<Long>(accountService.createAccount(account), HttpStatus.OK);
		}
		catch (Exception e) {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
	}
	
	@GetMapping(value = "/account/{accountNo}")
	public ResponseEntity<CustomerAccount> getAccount(@PathVariable("accountNo") Long accountNo) throws BankingException {
		try{
			return new ResponseEntity<CustomerAccount>(accountService.getAccount(accountNo), HttpStatus.OK);
		}catch (Exception e) {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
	}
	
	@PostMapping(value = "/addEntry/{accountNo}")
	public ResponseEntity<Boolean> addAccountEntry(@PathVariable("accountNo") Long accountNo,@RequestBody AccountEntry entry) throws BankingException {
		try{
			return new ResponseEntity<Boolean>(accountService.addAccountEntry(accountNo, entry), HttpStatus.OK);
		}catch (Exception e) {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
	}
	
	@GetMapping(value = "/account")
	public ResponseEntity<List<CustomerAccount>> getAllAccount() throws BankingException{
		try{
			return new ResponseEntity<List<CustomerAccount>>(accountService.getAllAccount(), HttpStatus.OK);
		}catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
	}
	
	@PostMapping(value = "/block/{accountNo}")
	public ResponseEntity<Boolean> blockAccount(@PathVariable("accountNo") Long accountNo) throws BankingException{
		try{
			return new ResponseEntity<Boolean>(accountService.blockAccount(accountNo), HttpStatus.OK);
		}catch (Exception e) {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
		
	}
	
	@PostMapping(value = "/activate/{accountNo}")
	public ResponseEntity<Boolean> activateAccount(@PathVariable("accountNo") Long accountNo) throws BankingException{
		try{
			return new ResponseEntity<Boolean>(accountService.activateAccount(accountNo), HttpStatus.OK);
		}catch (Exception e) {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
	}

}

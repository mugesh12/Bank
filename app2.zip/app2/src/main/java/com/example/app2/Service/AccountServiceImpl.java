package com.example.app2.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.app2.BankingException;
import com.example.app2.dto.AccountEntry;
import com.example.app2.dto.CustomerAccount;
import com.example.app2.entity.AccountEntryEntity;
import com.example.app2.entity.CustomerAccountEntity;
import com.example.app2.repository.AccountEntryRepository;
import com.example.app2.repository.CustomerAccountRepository;

@Service
public class AccountServiceImpl implements AccountService {
	
	@Autowired
	CustomerAccountRepository customerRepository;
	
	@Autowired
	AccountEntryRepository entryRepository;

	@Override
	public Long createAccount(CustomerAccount account) throws BankingException {
		if(!"Savings".equals(account.getAccountType()) && !"Current".equals(account.getAccountType())) {
			throw new BankingException("Account type must be Savings or Current");
		}
		if(account.getPin()==null || account.getPin().toString().length()!=4) {
			throw new BankingException("Pin must be 4 digit");
		}
		if(account.getCurrentBalance().compareTo(new BigDecimal(500l))<0) {
			throw new BankingException("Minimum balance must be 500");
		}
		CustomerAccountEntity entity=CustomerAccount.getEntity(account);
		entity.setActiveFlag(true);
		entity.setCreatedDate(Calendar.getInstance().getTime());
		entity=customerRepository.save(entity);
		return entity.getAccountId();
	}

	@Override
	public CustomerAccount getAccount(Long accountNo) throws BankingException {
		CustomerAccountEntity cusEntity=customerRepository.findByAccountId(accountNo);
		if(cusEntity==null) {
			throw new BankingException("Account doesn't exist. Please try again");
		}
		CustomerAccount cusDto=CustomerAccount.getDto(cusEntity);
		List<AccountEntry> accDtoList=new ArrayList<AccountEntry>();
		for(AccountEntryEntity accEntity:cusEntity.getAccountEntry()) {
			AccountEntry accDto=AccountEntry.getDto(accEntity);
			accDtoList.add(accDto);
		}
		cusDto.setAccountEntry(accDtoList);
		return cusDto;
	}

	@Override
	public Boolean addAccountEntry(Long accountNo, AccountEntry entry) throws BankingException {
		CustomerAccountEntity cusEntity=customerRepository.findByAccountId(accountNo);
		if(cusEntity==null) {
			throw new BankingException("Account doesn't exist. Please try again");
		}
		if(!cusEntity.getActiveFlag()) {
			throw new BankingException("Account is currently inactive");
		}
		if("Debit".equals(entry.getEntryType())) {
			if(cusEntity.getCurrentBalance().compareTo(entry.getAmount())<0) {
				throw new BankingException("Insufficient balance");
			}
			if(cusEntity.getCurrentBalance().subtract(entry.getAmount()).compareTo(new BigDecimal(500))<0) {
				throw new BankingException("Must have to maintain minimum balance");
			}
			cusEntity.setCurrentBalance(cusEntity.getCurrentBalance().subtract(entry.getAmount()));
		}
		else {
			cusEntity.setCurrentBalance(cusEntity.getCurrentBalance().add(entry.getAmount()));
		}
		customerRepository.save(cusEntity);
		AccountEntryEntity accEntity=AccountEntry.getEntity(entry);
		accEntity.setAccountId(cusEntity.getAccountId());
		accEntity.setAmountAfterTransaction(cusEntity.getCurrentBalance());
		accEntity.setEntryTimeStamp(Calendar.getInstance().getTime());
		entryRepository.save(accEntity);
		return true;
	}

	@Override
	public List<CustomerAccount> getAllAccount() throws BankingException {
		List<CustomerAccountEntity> cusEntityList=customerRepository.findAll();
		if(cusEntityList.isEmpty()) {
			throw new BankingException("No Accounts Exist");
		}
		List<CustomerAccount> cusDtoList=new ArrayList<CustomerAccount>();
		for(CustomerAccountEntity cusEntity:cusEntityList) {
			CustomerAccount cusDto=CustomerAccount.getDto(cusEntity);
			List<AccountEntry> accDtoList=new ArrayList<AccountEntry>();
			for(AccountEntryEntity accEntity:cusEntity.getAccountEntry()) {
				AccountEntry accDto=AccountEntry.getDto(accEntity);
				accDtoList.add(accDto);
			}
			cusDto.setAccountEntry(accDtoList);
			cusDtoList.add(cusDto);
		}
		return cusDtoList;
	}

	@Override
	public Boolean blockAccount(Long accountNo) throws BankingException {
		CustomerAccountEntity cusEntity=customerRepository.findByAccountId(accountNo);
		if(cusEntity==null) {
			throw new BankingException("Account doesn't exist");
		}
		if(!cusEntity.getActiveFlag()) {
			throw new BankingException("Account was already inactive");
		}
		cusEntity.setActiveFlag(false);
		customerRepository.save(cusEntity);
		return true;
	}
	
	@Override
	public Boolean activateAccount(Long accountNo) throws BankingException {
		CustomerAccountEntity cusEntity=customerRepository.findByAccountId(accountNo);
		if(cusEntity==null) {
			throw new BankingException("Account doesn't exist");
		}
		if(cusEntity.getActiveFlag()) {
			throw new BankingException("Account was already active");
		}
		cusEntity.setActiveFlag(true);
		customerRepository.save(cusEntity);
		return true;
	}

}

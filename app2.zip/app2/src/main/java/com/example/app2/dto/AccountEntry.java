package com.example.app2.dto;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.example.app2.entity.AccountEntryEntity;


public class AccountEntry{
	private Long entryId;
	private Long accountId;
	private Date entryTimeStamp;
	private String entryType;
	private BigDecimal amount;
	private BigDecimal amountAfterTransaction;
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public Date getEntryTimeStamp() {
		return entryTimeStamp;
	}
	public void setEntryTimeStamp(Date entryTimeStamp) {
		this.entryTimeStamp = entryTimeStamp;
	}
	public String getEntryType() {
		return entryType;
	}
	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public Long getEntryId() {
		return entryId;
	}
	public void setEntryId(Long entryId) {
		this.entryId = entryId;
	}
	public BigDecimal getAmountAfterTransaction() {
		return amountAfterTransaction;
	}
	public void setAmountAfterTransaction(BigDecimal amountAfterTransaction) {
		this.amountAfterTransaction = amountAfterTransaction;
	} 
	
	public static AccountEntryEntity getEntity(AccountEntry acc) {
		AccountEntryEntity acc1 =new AccountEntryEntity();
		acc1.setAccountId(acc.getAccountId());
		acc1.setAmount(acc.getAmount());
		acc1.setAmountAfterTransaction(acc.getAmountAfterTransaction());
		acc1.setEntryId(acc.getEntryId());
		acc1.setEntryTimeStamp(acc.getEntryTimeStamp());
		acc1.setEntryType(acc.getEntryType());
		return acc1;
	}
	
	public static AccountEntry getDto(AccountEntryEntity acc) {
		AccountEntry acc1 =new AccountEntry();
		acc1.setAccountId(acc.getAccountId());
		acc1.setAmount(acc.getAmount());
		acc1.setAmountAfterTransaction(acc.getAmountAfterTransaction());
		acc1.setEntryId(acc.getEntryId());
		acc1.setEntryTimeStamp(acc.getEntryTimeStamp());
		acc1.setEntryType(acc.getEntryType());
		return acc1;
	}
}
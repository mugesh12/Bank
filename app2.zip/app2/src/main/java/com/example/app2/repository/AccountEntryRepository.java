package com.example.app2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.app2.entity.AccountEntryEntity;

public interface AccountEntryRepository extends JpaRepository<AccountEntryEntity, Long>{

}
